-- MySQL dump 10.13  Distrib 5.7.9, for Win32 (AMD64)
--
-- Host: localhost    Database: assignment6
-- ------------------------------------------------------
-- Server version	5.7.9-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `2014302580390_pet`
--

DROP TABLE IF EXISTS `2014302580390_pet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `2014302580390_pet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `eat` varchar(45) NOT NULL,
  `drink` varchar(45) NOT NULL,
  `live` varchar(45) NOT NULL,
  `hobby` varchar(45) NOT NULL,
  `price` float NOT NULL,
  `action` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2014302580390_pet`
--

LOCK TABLES `2014302580390_pet` WRITE;
/*!40000 ALTER TABLE `2014302580390_pet` DISABLE KEYS */;
INSERT INTO `2014302580390_pet` VALUES (1,'蓝黄金刚鹦鹉','鸟饲料','水','笼子','学舌',398,'fly'),(2,'相思鸟','鸟饲料','水','笼子','思念',198,'fly'),(3,'绣眼鸟','鸟饲料','水','笼子','卖萌',168,'fly'),(4,'太平洋鹦鹉','鸟饲料','水','笼子','学舌',358,'fly'),(5,'画眉','鸟饲料','水','笼子','唱歌',98,'fly'),(6,'金丝雀','鸟饲料','水','笼子','唱歌',168,'fly'),(7,'文须雀','鸟饲料','水','笼子','卖萌',128,'fly'),(8,'灰伯劳','鸟饲料','水','笼子','唱歌',298,'fly'),(9,'鹅头红','鱼食','水','鱼缸','忘记',28,'swim'),(10,'十二红蝶尾','鱼食','水','鱼缸','忘记',38,'swim'),(11,'神仙鱼','鱼食','水','鱼缸','忘记',68,'swim'),(12,'星点珍珠虾','鱼食','水','鱼缸','忘记',28,'swim'),(13,'熊猫神仙','鱼食','水','鱼缸','忘记',58,'swim'),(14,'红宝石','鱼食','水','鱼缸','忘记',78,'swim'),(15,'小蜜蜂','鱼食','水','鱼缸','忘记',38,'swim'),(16,'接吻鱼','鱼食','水','鱼缸','忘记',38,'swim'),(17,'巧克力娃娃','鱼食','水','鱼缸','忘记',28,'swim'),(18,'宝莲灯鱼','鱼食','水','鱼缸','忘记',68,'swim'),(19,'红鼻剪刀','鱼食','水','鱼缸','忘记',28,'swim'),(20,'一眉道人','鱼食','水','鱼缸','忘记',58,'swim'),(21,'蜜蜂虾','鱼食','水','鱼缸','忘记',38,'swim'),(22,'斑马虾','鱼食','水','鱼缸','忘记',38,'swim'),(23,'哈士奇','各种各样的食物','水','窝','玩耍，陪伴',1638,'crawl'),(24,'蝴蝶犬','各种各样的食物','水','窝','玩耍，陪伴',998,'crawl'),(25,'马尔济斯犬','各种各样的食物','水','窝','玩耍，陪伴',1268,'crawl'),(26,'卷毛比雄犬','各种各样的食物','水','窝','玩耍，陪伴',1398,'crawl'),(27,'西高地雪白梗','各种各样的食物','水','窝','玩耍，陪伴',1568,'crawl'),(28,'波斯猫','各种各样的食物','水','窝','玩耍，陪伴',898,'crawl'),(29,'布偶猫','各种各样的食物','水','窝','玩耍，陪伴',798,'crawl'),(30,'俄罗斯蓝猫','各种各样的食物','水','窝','玩耍，陪伴',998,'crawl'),(31,'土拨鼠','各种各样的食物','水','窝','玩耍，陪伴',98,'hole'),(32,'红玫瑰','虫子','水','盒子','织网',158,'hole'),(33,'玉米蛇','各种各样的食物','水','窝','冬眠',398,'hole');
/*!40000 ALTER TABLE `2014302580390_pet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-12-04 22:55:39
